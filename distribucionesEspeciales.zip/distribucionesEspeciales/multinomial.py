# -*- coding: utf-8 -*-
"""
Created on Thu Sep 28 00:15:17 2017

@author: jdk2py
"""

from scipy.stats import multinomial
