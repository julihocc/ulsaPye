# -*- coding: utf-8 -*-
"""
Created on Sun Oct  1 12:15:46 2017

@author: jdk2py
"""

import math
import scipy.special

print math.factorial(5)
print scipy.special.binom(8,3)