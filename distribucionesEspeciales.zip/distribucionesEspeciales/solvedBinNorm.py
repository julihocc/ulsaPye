# -*- coding: utf-8 -*-
"""
Created on Thu Sep 28 22:27:06 2017

@author: jdk2py
"""

